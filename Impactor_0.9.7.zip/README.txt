PASS: 123

If you can't use Impactor 0.9.7 - check latest version http://asautman.top/impactor0 (use beta 0.9.8)